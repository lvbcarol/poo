/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.maua.t2._maua_tti101_t2_sistema_academico;

/**
 *
 * @author carol
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
